namespace NavegacionMaui_AGRZ.Views;

public partial class InformacionPage : ContentPage
{
    public InformacionPage()
    {
        InitializeComponent();
    }

    // Regresa a la pantalla que se abrió anteriormente.
    private async void VolverInicio(
        object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("..");
    }
}