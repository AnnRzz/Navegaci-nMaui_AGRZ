namespace NavegacionMaui_AGRZ.Views;

public partial class InicioPage : ContentPage
{
    public InicioPage()
    {
        InitializeComponent();
    }

    // Abre la sección donde se muestra la información.
    private async void AbrirInformacion(
        object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("informacion");
    }
}