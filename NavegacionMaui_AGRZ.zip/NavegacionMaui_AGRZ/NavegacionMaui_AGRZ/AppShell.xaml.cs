﻿using NavegacionMaui_AGRZ.Views;

namespace NavegacionMaui_AGRZ;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        // Se registra la página para poder navegar hacia ella.
        Routing.RegisterRoute(
            "informacion",
            typeof(InformacionPage));
    }
}