﻿using Microsoft.Extensions.DependencyInjection;

namespace NavegacionMaui_AGRZ
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            return new Window(new AppShell());
        }
    }
}